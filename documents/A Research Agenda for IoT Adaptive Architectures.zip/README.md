#Learning Action from the context

- **Venue:** [SEAMS'18](https://conf.researchr.org/track/seams-2018/seams-2018-papers#Call-for-Papers) 

## Description
This repo contains the latex structure for the **Adaptation in IoT Environments** paper. 

The main file of the paper is _main.tex_ containing the structure definition and references to all input files. There is a file for each independent section of the paper.


## Structure 

* preamble: contains all package and command definitions. Everything should be set by now, but if something needs defining this is the place to do it (look inside to see the structure)
* bibfiles
    * local.bib: contains all local bib references i.e., references used for this paper specifically. Most references should be added here.
	* Bibliography ids should be defined with the lastname of the first author and the last two digits of the publication year (e.g., cardozo12)
* acronym.tex: contains all Acronyms used in the paper (look in the file for examples of the definition). Acronyms are used with the _\ac{ACRONYM}_ command
	* _\ac{}_ displays the acronym (and the full name (acronym) the first time it appears in the text)
	* _\acp{}_ displays the plural of the acronym
	* _\acl{}_ displays the long name of the acronym
	* _\acs{}_ displays just the acronym
	* _\acf{}_ displays the long name (acronym)
* there is a .tex file for each independent section (_\section{SECTION_NAME}_)


## Useful commands
* _\authorcomment[TYPE]{AUTHOR}{COMMENT}_ is used to leave annotation inlined with the text. Comments only appear in draft mode (the option in the documentclass in the _main.tex_ file) and are invisible otherwise. Type can be comment, missing, idea,
* _\ie_ _\eg_ _\cf_ are used respectively for the abbreviations i.e., e.g., cf.
* Bibliography items should be referenced using _~\cite{}_, if the name of the author is required _~\citet{}_ should be used
* References to Sections, Tables, Figures, Snippets:
	* Section labels should be defined as _\label{sec:}_
	* Figure labels should be defined as _\label{fig:}_
	* Table labels should be defined as _\label{tab:}_
	* Snippet labels should be defined as _\label{lst:}_
 To reference a particular object of the previously defined use the command _\fref{objectType:name}_ (e.g., _\fref{sec:introduction}_) which will display the corresponding object type name and number (e.g., Section 1)
* listings are defined according to each specific language in the _preamble_ file and generate their own environment (e.g., _\ctxraits[....]{....}_ generates a contexts traits listing).